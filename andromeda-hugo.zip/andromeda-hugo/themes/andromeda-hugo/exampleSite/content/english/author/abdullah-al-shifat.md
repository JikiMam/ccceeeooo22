---
title: "Abdullah Al Shifat"
image: "images/author/abdullah.jpg"
email: "sojon.themefisher@gmail.com"
social:
  - icon : "lab la-linkedin-in"
    name: "linkedin"
    link : "#!"
  - icon : "lab la-twitter"
    name: "twitter"
    link : "#!"
---

Hic dolor cumque quod quas pariatur modi rerum qui consequatur, iusto inventore necessitatibus. Facilis quisquam magni, autem deleniti nobis repellat excepturi id.