---
title: "How It Works"
layout: "how-it-works"
draft: false

how_it_works_video:
  enable: true
  subtitle: "Our Features"
  title: "How it works"
  description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi egestas <br> Werat viverra id et aliquet. vulputate egestas sollicitudin."
  video_url: "https://www.youtube.com/embed/dyZcRRWiuuw"
  video_thumbnail: "images/video-popup.jpg"


# how_it_works
how_it_works:   
  enable: true
  block:
  - subtitle: "Primary Speciality"
    title: "You Will Not miss Your All misunderstandings"
    description: "Protect your design vision and leave nothing up to interpretation with interaction recipes. Quickly share and access all your team members interactions by using libraries, ensuring consistency throughout the."
    image: "images/features-01.png"

  - subtitle: "Secondary Speciality"
    title: "Say hello to no-code The Advance Creation"
    description: "From the simplest of interactions to those that use Excel-gradeing formulas, ProtoPie can handle them all. Make mind-blowing of New interactions everyday without ever having to write any new code."
    image: "images/features-02.png"

---