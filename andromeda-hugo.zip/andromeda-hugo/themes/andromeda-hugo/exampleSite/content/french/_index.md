---
# banner
banner:
  title: "Andromeda est le moyen le plus intuitif de prototyper des conceptions"
  button: "Télécharger le thème"
  button_link: "#!"
  image: "images/banner-app.png"


# brands
brands_carousel:
  enable: true
  brand_images:
  - "images/brands/01-colored.png"
  - "images/brands/02-colored.png"
  - "images/brands/04-colored.png"
  - "images/brands/03-colored.png"
  - "images/brands/05-colored.png"
  - "images/brands/06-colored.png"
  - "images/brands/04-colored.png"
  - "images/brands/02-colored.png"
  - "images/brands/01-colored.png"
  - "images/brands/06-colored.png"
  - "images/brands/05-colored.png"


# features
features:
  enable: true
  subtitle: "Caractéristiques spéciales"
  title: "Éléments pour <br> vous aider à démarrer"
  description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi egestas <br> Werat viverra id et aliquet. vulputate egestas sollicitudin."
  features_blocks:
  - icon: "las la-lock"
    title: "Sécurité mise à jour"
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque enim id diam ornare volutpat in sagitis, aliquet. Arcu cursus"
  - icon: "las la-magnet"
    title: "Tournage magnétique"
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque enim id diam ornare volutpat in sagitis, aliquet. Arcu cursus"
  - icon: "las la-tachometer-alt"
    title: "Sécurisé et à jour"
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque enim id diam ornare volutpat in sagitis, aliquet. Arcu cursus"
  - icon: "las la-link"
    title: "Partage de lien instantané"
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque enim id diam ornare volutpat in sagitis, aliquet. Arcu cursus"
  - icon: "las la-lock"
    title: "Sécurité mise à jour"
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque enim id diam ornare volutpat in sagitis, aliquet. Arcu cursus"
  - icon: "las la-magnet"
    title: "Tournage magnétique"
    content: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Neque enim id diam ornare volutpat in sagitis, aliquet. Arcu cursus"


# intro_video
intro_video:   
  enable: true
  subtitle: "Courte vidéo d'introduction"
  title: "Construit exclusivement pour vous"
  description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi egestas <br> Werat viverra id et aliquet. vulputate egestas sollicitudin."
  video_url: "https://www.youtube.com/embed/dyZcRRWiuuw"
  video_thumbnail: "images/video-popup.jpg"


# how_it_works
how_it_works:   
  enable: true
  section: "how-it-works" # content comming from how-it-works page


# testimonials
testimonials:   
  enable: true
  subtitle: "Notre témoignage"
  title: "Ne nous croyez pas sur parole"
  description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi egestas <br> Werat viverra id et aliquet. vulputate egestas sollicitudin."
  image_left: "images/testimonials-01.png"
  image_right: "images/testimonials-02.png"
  
  testimonials_quotes:
  - quote: "Lorem ipsum dolor amet, conseetur adipiscing elit. Ornare quam porta arcu congue felis volutpat. Vitae lectudbfs dolor faucibus"
    name: "David Cameron"
    designation: "CEO, Nexuspay"
    image: "images/user-img/05-i.jpg"

  - quote: "Conseetur adipiscing elit. Ornare quam porta arcu congue felis volutpat. Vitae lectudbfs pellentesque vitae dolor faucibus"
    name: "David Cameron"
    designation: "CEO, Nexuspay"
    image: "images/user-img/06-i.jpg"

  - quote: "Lorem ipsum dolor amet, conseetur adipiscing elit. Ornare quam porta arcu congue felis volutpat. Vitae lectudbfs pellentesque vitae dolor"
    name: "David Cameron"
    designation: "CEO, Nexuspay"
    image: "images/user-img/07-i.jpg"

  - quote: "Lorem ipsum dolor amet, conseetur adipiscing elit. porta arcu congue felis volutpat. Vitae lectudbfs pellentesque vitae dolor faucibus"
    name: "David Cameron"
    designation: "CEO, Nexuspay"
    image: "images/user-img/08-i.jpg"

  - quote: "Lorem ipsum dolor ame conseetur. Ornare quam porta arcu congue felis volutpat. Vitae lectudbfs pellentesque vitae dolor faucibus"
    name: "David Cameron"
    designation: "CEO, Nexuspay"
    image: "images/user-img/09-i.jpg"

  - quote: "Lorem ipsum dolor amet, conseetur adipiscing elit. Ornare quam porta arcu congue lectudbfs pellentesque vitae dolor faucibus"
    name: "David Cameron"
    designation: "CEO, Nexuspay"
    image: "images/user-img/10-i.jpg"

---